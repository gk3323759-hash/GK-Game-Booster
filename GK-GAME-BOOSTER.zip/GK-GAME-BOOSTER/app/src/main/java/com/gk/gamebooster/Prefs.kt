package com.gk.gamebooster

import android.content.Context

/** App settings stored in SharedPreferences. */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("gk", Context.MODE_PRIVATE)

    fun autoBoost(c: Context): Boolean = p(c).getBoolean("autoBoost", true)
    fun setAutoBoost(c: Context, v: Boolean) = p(c).edit().putBoolean("autoBoost", v).apply()

    fun vibrate(c: Context): Boolean = p(c).getBoolean("vibrate", true)
    fun setVibrate(c: Context, v: Boolean) = p(c).edit().putBoolean("vibrate", v).apply()

    fun roundSeconds(c: Context): Int = p(c).getInt("round", 30)
    fun setRoundSeconds(c: Context, v: Int) = p(c).edit().putInt("round", v).apply()
}
