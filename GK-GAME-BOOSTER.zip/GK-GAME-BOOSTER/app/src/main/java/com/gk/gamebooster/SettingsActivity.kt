package com.gk.gamebooster

import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat

class SettingsActivity : BaseActivity("Settings") {

    override fun build() {
        content.removeAllViews()

        // ---- Switches ----
        val sw = Ui.card(this)
        sw.addView(Ui.tv(this, "General", 18f, true, Ui.RED))
        sw.addView(switchRow("Auto-boost before launching a game",
            "Stops background apps when you tap PLAY.", Prefs.autoBoost(this)) { Prefs.setAutoBoost(this, it) }, Ui.lp(this, 10))
        sw.addView(switchRow("Vibrate on headshot",
            "Short vibration in Headshot Training.", Prefs.vibrate(this)) { Prefs.setVibrate(this, it) }, Ui.lp(this, 10))
        content.addView(sw, Ui.lp(this))

        // ---- Trainer length ----
        val tr = Ui.card(this)
        tr.addView(Ui.tv(this, "Headshot Training round length", 16f, true, Ui.RED))
        val row = LinearLayout(this)
        for (s in listOf(15, 30, 60)) {
            val lp = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
            lp.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0)
            row.addView(Ui.button(this, "${s}s", Prefs.roundSeconds(this) == s) {
                Prefs.setRoundSeconds(this, s)
                build()
            }, lp)
        }
        tr.addView(row, Ui.lp(this, 8))
        content.addView(tr, Ui.lp(this, 12))

        // ---- Data ----
        val data = Ui.card(this)
        data.addView(Ui.tv(this, "Data", 16f, true, Ui.RED))
        data.addView(Ui.button(this, "Reset best trainer score", false) {
            confirm("Reset best score?") { GameStore.resetBest(this); toast("Best score reset") }
        }, Ui.lp(this, 8))
        data.addView(Ui.button(this, "Remove all added games", false) {
            confirm("Remove all games you added?") { GameStore.clearCustom(this); toast("Added games removed") }
        }, Ui.lp(this, 8))
        content.addView(data, Ui.lp(this, 12))

        // ---- About ----
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
        } catch (e: Exception) {
            "1.0"
        }
        val about = Ui.card(this)
        about.addView(Ui.tv(this, "About", 16f, true, Ui.RED))
        about.addView(Ui.tv(this,
            "GK GAME BOOSTER v$version\nPackage: $packageName\n\n" +
            "Supports Free Fire, Free Fire MAX, BGMI and PUBG Mobile launching.\n\n" +
            "This app does not modify any game, give in-game advantages or use cheats. " +
            "It is not affiliated with Garena, Krafton or Tencent. All game names belong to their owners.", 14f), Ui.lp(this, 6))
        content.addView(about, Ui.lp(this, 12))
    }

    private fun switchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = android.view.Gravity.CENTER_VERTICAL
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.addView(Ui.tv(this, title, 15f, true))
        left.addView(Ui.tv(this, desc, 12f, false, Ui.MUTED))
        row.addView(left, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        val s = SwitchCompat(this)
        s.isChecked = checked
        s.setOnCheckedChangeListener { _, v -> onChange(v) }
        row.addView(s)
        return row
    }

    private fun confirm(title: String, action: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setPositiveButton("Yes") { _, _ -> action() }
            .setNegativeButton("No", null)
            .show()
    }
}
