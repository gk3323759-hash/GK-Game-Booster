package com.gk.gamebooster

import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

abstract class BaseActivity(private val screenTitle: String) : AppCompatActivity() {
    lateinit var root: LinearLayout
    lateinit var scroll: ScrollView
    lateinit var content: LinearLayout
    open val showBack: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.DARK_RED

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setBackgroundColor(Ui.RED)
        val pad = Ui.dp(this, 16)
        header.setPadding(pad, Ui.dp(this, 14), pad, Ui.dp(this, 14))
        if (showBack) {
            val back = Ui.tv(this, "←", 24f, true, android.graphics.Color.WHITE)
            back.setPadding(0, 0, pad, 0)
            back.setOnClickListener { finish() }
            header.addView(back)
        }
        header.addView(Ui.tv(this, screenTitle, 20f, true, android.graphics.Color.WHITE))
        root.addView(header, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        scroll = ScrollView(this)
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        val p = Ui.dp(this, 14)
        content.setPadding(p, p, p, p)
        scroll.addView(content, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        setContentView(root)
        build()
    }

    abstract fun build()

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
