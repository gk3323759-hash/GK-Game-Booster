package com.gk.gamebooster

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.random.Random

/** Simple aim-training game: tap the head (bonus) or body of moving targets for 30 seconds. */
class TrainerView(ctx: Context) : View(ctx) {
    interface Listener { fun onFinish() }

    var listener: Listener? = null
    var running = false
        private set
    var difficulty = 1   // 0 easy, 1 medium, 2 hard

    var score = 0
    var hits = 0
    var headshots = 0
    var shots = 0
    var combo = 0
    var bestCombo = 0

    private val d = resources.displayMetrics.density
    private var roundMs = 30000L
    private var endAt = 0L
    private var lastFrame = 0L
    private var spawnAt = 0L
    private var lifeMs = 1200L
    private var tx = 0f
    private var ty = 0f
    private var r = 30f
    private var vx = 0f
    private var flash = ""
    private var flashUntil = 0L

    private val bg = Paint().apply { color = Color.WHITE }
    private val border = Paint().apply { color = Ui.RED; style = Paint.Style.STROKE; strokeWidth = 3f * d }
    private val head = Paint().apply { color = Ui.RED; isAntiAlias = true }
    private val ring = Paint().apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f * d; isAntiAlias = true }
    private val body = Paint().apply { color = Color.parseColor("#7A0F18"); isAntiAlias = true }
    private val lifeBar = Paint().apply { color = Color.parseColor("#FFB3B8") }
    private val text = Paint().apply { color = Ui.TEXT; textSize = 16f * d; isAntiAlias = true; isFakeBoldText = true }
    private val big = Paint().apply { color = Ui.RED; textSize = 26f * d; isAntiAlias = true; isFakeBoldText = true; textAlign = Paint.Align.CENTER }

    fun start() {
        score = 0; hits = 0; headshots = 0; shots = 0; combo = 0; bestCombo = 0
        running = true
        roundMs = Prefs.roundSeconds(context) * 1000L
        val now = SystemClock.uptimeMillis()
        endAt = now + roundMs
        lastFrame = now
        spawn()
        invalidate()
    }

    private fun rnd(a: Float, b: Float) = if (b <= a) a else a + Random.nextFloat() * (b - a)

    private fun spawn() {
        val w = width.toFloat()
        val h = height.toFloat()
        r = (when (difficulty) { 0 -> 42f; 1 -> 32f; else -> 24f }) * d
        lifeMs = when (difficulty) { 0 -> 1700L; 1 -> 1250L; else -> 900L }
        val half = r * 1.3f
        tx = rnd(half, w - half)
        ty = rnd(r + 40f * d, h - r * 4.5f)
        val speed = when (difficulty) { 0 -> 0f; 1 -> 60f; else -> 130f } * d
        vx = if (Random.nextBoolean()) speed else -speed
        spawnAt = SystemClock.uptimeMillis()
    }

    override fun onDraw(c: Canvas) {
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), border)
        if (!running) {
            c.drawText("Press START", width / 2f, height / 2f, big)
            return
        }
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastFrame) / 1000f
        lastFrame = now
        val left = endAt - now
        if (left <= 0) {
            running = false
            listener?.onFinish()
            invalidate()
            return
        }
        tx += vx * dt
        val half = r * 1.3f
        if (tx < half) { tx = half; vx = abs(vx) }
        if (tx > width - half) { tx = width - half; vx = -abs(vx) }
        if (now - spawnAt > lifeMs) { combo = 0; spawn() }

        // body + head
        c.drawRoundRect(RectF(tx - r * 1.3f, ty + r * 1.1f, tx + r * 1.3f, ty + r * 4.2f), r * 0.4f, r * 0.4f, body)
        c.drawCircle(tx, ty, r, head)
        c.drawCircle(tx, ty, r * 0.55f, ring)
        // life bar
        val frac = 1f - (now - spawnAt).toFloat() / lifeMs
        c.drawRect(tx - r * 1.3f, ty + r * 4.4f, tx - r * 1.3f + r * 2.6f * frac.coerceIn(0f, 1f), ty + r * 4.6f, lifeBar)

        // HUD
        c.drawText("Time ${left / 1000 + 1}s   Score $score   Combo $combo", 12f * d, 24f * d, text)
        if (now < flashUntil) c.drawText(flash, width / 2f, height - 20f * d, big)
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            parent?.requestDisallowInterceptTouchEvent(true)
            if (running) tap(e.x, e.y)
        }
        return true
    }

    private fun tap(x: Float, y: Float) {
        shots++
        val dx = x - tx
        val dy = y - ty
        val inHead = dx * dx + dy * dy <= (r * 1.1f) * (r * 1.1f)
        val inBody = abs(dx) <= r * 1.3f && y >= ty + r * 1.1f && y <= ty + r * 4.2f
        val now = SystemClock.uptimeMillis()
        if (inHead) {
            hits++; headshots++; combo++
            score += 100 + combo * 10
            buzz()
            flash = "HEADSHOT!"
            flashUntil = now + 500
            if (combo > bestCombo) bestCombo = combo
            spawn()
        } else if (inBody) {
            hits++; combo++
            score += 40
            flash = "Body hit"
            flashUntil = now + 400
            if (combo > bestCombo) bestCombo = combo
            spawn()
        } else {
            combo = 0
            score = maxOf(0, score - 20)
            flash = "Miss"
            flashUntil = now + 400
        }
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        if (!Prefs.vibrate(context)) return
        val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            v.vibrate(35)
        }
    }
}
