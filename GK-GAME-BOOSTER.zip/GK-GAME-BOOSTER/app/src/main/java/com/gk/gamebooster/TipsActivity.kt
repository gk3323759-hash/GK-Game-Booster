package com.gk.gamebooster

import android.view.View
import android.widget.LinearLayout

class TipsActivity : BaseActivity("Gaming Tips") {
    private data class Cat(val emoji: String, val title: String, val tips: List<String>)

    private val cats = listOf(
        Cat("🎯", "Aim & Shooting", listOf(
            "Keep your crosshair at head height while moving.",
            "Fire in short bursts instead of holding the trigger for a long time.",
            "Use smooth, short drags toward the head instead of big flicks.",
            "Practise 5 minutes daily in Headshot Training before ranked matches.",
            "Use the scope that suits the distance: low zoom close, higher zoom far."
        )),
        Cat("🪂", "Landing & Looting", listOf(
            "Pick a landing spot you can reach quickly; busy spots mean early fights.",
            "Grab a weapon first, then armor and healing.",
            "Don't over-loot: take what you need and move before the zone shrinks.",
            "Check your inventory while behind cover, not in the open."
        )),
        Cat("🏃", "Movement & Positioning", listOf(
            "Use cover and break line of sight before healing or reloading.",
            "Move to the safe zone early to avoid crowded rotations.",
            "Hold high ground when you can; it gives you better view.",
            "Don't run in straight lines across open ground."
        )),
        Cat("👥", "Squad Play", listOf(
            "Call out enemy position, distance and health with your team.",
            "Stay close enough to revive a teammate quickly.",
            "Agree on one plan before pushing a fight.",
            "Share ammo and healing items with your squad."
        )),
        Cat("🔥", "Free Fire Tips", listOf(
            "Use Gloo Walls for cover while healing or pushing.",
            "Learn your character's skill and build your squad around it.",
            "Fight in buildings and tight spots with a close-range weapon.",
            "Use Free Look to check angles without exposing yourself."
        )),
        Cat("🪖", "BGMI / PUBG Mobile Tips", listOf(
            "Use headphones: footsteps and gunshots tell you where enemies are.",
            "Control recoil by firing short bursts and pulling down smoothly.",
            "At long range, aim slightly above the target to account for bullet drop.",
            "Carry smokes and grenades; they are great for safe revives and pushes."
        )),
        Cat("📱", "Device Setup", listOf(
            "Close background apps (use ⚡ Boost) before you play.",
            "Choose Smooth/Standard graphics and the highest stable FPS.",
            "Turn on Do Not Disturb so notifications don't interrupt matches.",
            "Keep the phone cool; remove thick cases and don't charge while playing."
        )),
        Cat("🌐", "Network", listOf(
            "Use 5 GHz Wi-Fi close to the router or a strong mobile signal.",
            "Pause downloads and streaming on other devices.",
            "Pick the server closest to you."
        )),
        Cat("🧠", "Mindset & Ranking", listOf(
            "Play for survival in the early game; fights are easier with the zone on your side.",
            "Review what went wrong after a loss, not just who killed you.",
            "Take breaks after losing streaks; tilt hurts aim and decisions.",
            "Stay hydrated and sit with good posture for long sessions."
        ))
    )

    override fun build() {
        content.addView(Ui.tv(this, "Tap a category to open or close it.", 14f, false, Ui.MUTED))
        for ((index, c) in cats.withIndex()) {
            val card = Ui.card(this)
            val header = LinearLayout(this)
            header.orientation = LinearLayout.HORIZONTAL
            header.gravity = android.view.Gravity.CENTER_VERTICAL
            header.addView(Ui.iconBubble(this, c.emoji, 44))
            val title = Ui.tv(this, c.title, 17f, true, Ui.RED)
            title.setPadding(Ui.dp(this, 12), 0, 0, 0)
            header.addView(title)
            card.addView(header)

            val body = Ui.tv(this, c.tips.joinToString("\n\n") { "• $it" }, 14f)
            body.visibility = if (index == 0) View.VISIBLE else View.GONE
            card.addView(body, Ui.lp(this, 10))
            card.setOnClickListener {
                body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
            content.addView(card, Ui.lp(this, 10))
        }
    }
}
