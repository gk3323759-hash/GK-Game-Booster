package com.gk.gamebooster

import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.widget.ProgressBar
import android.widget.TextView

class PerformanceActivity : BaseActivity("RAM & Performance") {
    private lateinit var memText: TextView
    private lateinit var storageText: TextView
    private lateinit var bar: ProgressBar

    private fun gb(bytes: Long) = String.format("%.1f GB", bytes / 1073741824.0)

    override fun build() {
        val card = Ui.card(this)
        card.addView(Ui.tv(this, "Device status", 18f, true, Ui.RED))
        memText = Ui.tv(this, "", 15f)
        storageText = Ui.tv(this, "", 15f)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.progressTintList = ColorStateList.valueOf(Ui.RED)
        card.addView(memText, Ui.lp(this, 8))
        card.addView(bar, Ui.lp(this, 4))
        card.addView(storageText, Ui.lp(this, 8))
        content.addView(card, Ui.lp(this))

        content.addView(Ui.button(this, "🧹 Clean RAM now") {
            val n = Booster.boost(this, GameStore.allPackages(this))
            toast("Asked $n background apps to stop")
            bar.postDelayed({ refresh() }, 800)
        }, Ui.lp(this, 12))
        content.addView(Ui.button(this, "🔋 Battery saver settings", false) { open(Settings.ACTION_BATTERY_SAVER_SETTINGS) }, Ui.lp(this, 8))
        content.addView(Ui.button(this, "📱 Display settings (refresh rate)", false) { open(Settings.ACTION_DISPLAY_SETTINGS) }, Ui.lp(this, 8))
        content.addView(Ui.button(this, "🛠 Developer options", false) { open(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS) }, Ui.lp(this, 8))

        val tips = Ui.card(this)
        tips.addView(Ui.tv(this, "Performance tips", 18f, true, Ui.RED))
        tips.addView(Ui.tv(this,
            "• Use One-Tap Boost & Play before every match.\n" +
            "• Keep 10%+ storage free; delete unused apps and old videos.\n" +
            "• In-game: use Smooth/Standard graphics and the highest FPS option available.\n" +
            "• Turn off battery saver while gaming.\n" +
            "• Keep the phone cool: no thick case, don't charge while playing.\n" +
            "• Close recent apps and avoid heavy downloads during matches.\n" +
            "• Restart the phone regularly to clear memory leaks.\n" +
            "• Update the game and Android System WebView/Play services.\n" +
            "• Use stable Wi-Fi (5 GHz) or a strong mobile signal.\n" +
            "• Disable animations in Developer options only if you know what you're doing.", 14f), Ui.lp(this, 8))
        content.addView(tips, Ui.lp(this, 12))

        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (::bar.isInitialized) refresh()
    }

    private fun refresh() {
        val mi = Booster.memInfo(this)
        val usedPct = ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toInt()
        bar.progress = usedPct
        memText.text = "RAM: ${gb(mi.availMem)} free of ${gb(mi.totalMem)} ($usedPct% used)"
        val st = StatFs(Environment.getDataDirectory().path)
        storageText.text = "Storage: ${gb(st.availableBytes)} free of ${gb(st.totalBytes)}"
    }

    private fun open(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: ActivityNotFoundException) {
            toast("Not available on this phone")
        }
    }
}
