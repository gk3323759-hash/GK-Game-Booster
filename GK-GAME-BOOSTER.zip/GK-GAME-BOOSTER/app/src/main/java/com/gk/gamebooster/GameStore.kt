package com.gk.gamebooster

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo

data class Game(val name: String, val pkg: String, val custom: Boolean)

object GameStore {
    val builtin = listOf(
        Game("Free Fire", "com.dts.freefireth", false),
        Game("Free Fire MAX", "com.dts.freefiremax", false),
        Game("BGMI", "com.pubg.imobile", false),
        Game("PUBG Mobile", "com.tencent.ig", false)
    )
    val builtinPackages: Set<String> = builtin.map { it.pkg }.toSet()

    private fun prefs(c: Context) = c.getSharedPreferences("gk", Context.MODE_PRIVATE)

    fun customPackages(c: Context): Set<String> =
        prefs(c).getStringSet("custom", emptySet()) ?: emptySet()

    fun add(c: Context, pkg: String) {
        val s = customPackages(c).toMutableSet()
        s.add(pkg)
        prefs(c).edit().putStringSet("custom", s).apply()
    }

    fun remove(c: Context, pkg: String) {
        val s = customPackages(c).toMutableSet()
        s.remove(pkg)
        prefs(c).edit().putStringSet("custom", s).apply()
    }

    fun label(c: Context, pkg: String): String = try {
        val pm = c.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    fun all(c: Context): List<Game> =
        builtin + customPackages(c).map { Game(label(c, it), it, true) }.sortedBy { it.name.lowercase() }

    fun allPackages(c: Context): Set<String> = builtinPackages + customPackages(c)

    fun launchIntent(c: Context, pkg: String): Intent? = c.packageManager.getLaunchIntentForPackage(pkg)

    fun isInstalled(c: Context, pkg: String): Boolean = launchIntent(c, pkg) != null

    // best-high score for the trainer
    fun bestScore(c: Context): Int = prefs(c).getInt("best", 0)
    fun saveBest(c: Context, v: Int) = prefs(c).edit().putInt("best", v).apply()
    fun resetBest(c: Context) = prefs(c).edit().putInt("best", 0).apply()
    fun clearCustom(c: Context) = prefs(c).edit().remove("custom").apply()
}

object Booster {
    fun memInfo(c: Context): ActivityManager.MemoryInfo {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi
    }

    /** Returns battery percent and temperature in Celsius. */
    fun battery(c: Context): Pair<Int, Float> {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra("level", -1) ?: -1
        val scale = i?.getIntExtra("scale", 100) ?: 100
        val temp = (i?.getIntExtra("temperature", 0) ?: 0) / 10f
        val pct = if (level < 0 || scale <= 0) 0 else level * 100 / scale
        return Pair(pct, temp)
    }

    /** Asks Android to stop background processes of user-installed apps (except games & this app). */
    fun boost(c: Context, keep: Set<String>): Int {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        var n = 0
        for (app in c.packageManager.getInstalledApplications(0)) {
            if (app.packageName == c.packageName || app.packageName in keep) continue
            if ((app.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            try {
                am.killBackgroundProcesses(app.packageName)
                n++
            } catch (e: Exception) {
            }
        }
        return n
    }
}
