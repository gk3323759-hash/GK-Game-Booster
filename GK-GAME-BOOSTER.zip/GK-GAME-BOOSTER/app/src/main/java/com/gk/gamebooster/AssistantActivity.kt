package com.gk.gamebooster

import android.graphics.Color
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.content.Context

/** Offline, rule-based gaming assistant (no internet or API key needed). */
class AssistantActivity : BaseActivity("AI Gaming Assistant") {
    private data class Topic(val keys: List<String>, val answer: String)

    private val topics = listOf(
        Topic(listOf("sens", "sensitivity", "dpi", "slider"),
            "Open Free Fire Sensitivity in this app and pick a preset (Rusher, Balanced or Precision). Then test in the game's training room: if you overshoot targets, lower General and Red Dot by 5–10; if you can't turn fast enough, raise them. Change one slider at a time. Smaller screens usually need higher values, bigger screens lower."),
        Topic(listOf("headshot", "aim", "head", "accuracy", "recoil", "drag"),
            "Headshot routine: 5 minutes of Headshot Training daily. Start on Easy, move up when your headshot rate passes 50%. In matches keep your crosshair at head height while moving, fire in short bursts, and use smooth short drags toward the head instead of big flicks."),
        Topic(listOf("lag", "fps", "stutter", "slow", "ram", "memory", "performance", "smooth"),
            "Fix lag: 1) Use One-Tap Boost & Play to stop background apps. 2) Keep at least 10% storage free. 3) Lower graphics to Smooth/Standard and pick the highest FPS your phone allows. 4) Turn off battery saver while gaming. 5) Restart the phone once a day if it feels sluggish."),
        Topic(listOf("heat", "hot", "overheat", "temperature", "cool"),
            "Overheating: remove thick cases, don't charge while playing, lower brightness, use Smooth graphics, and take a short break between matches. A hot phone throttles and lowers FPS."),
        Topic(listOf("battery", "charge", "power"),
            "Battery: lower brightness, turn off battery saver only while gaming (it limits performance), close background apps, and avoid playing while fast charging if the phone gets hot."),
        Topic(listOf("ping", "network", "wifi", "wi-fi", "latency", "internet", "data"),
            "Network: use 5 GHz Wi-Fi close to the router or a stable 4G/5G signal, pause downloads/streaming on other devices, and choose the nearest server region."),
        Topic(listOf("rank", "push", "win", "survive", "strategy", "tips", "zone"),
            "Ranking tips: land where you can loot safely, rotate to the zone early, use cover when healing, play with a squad that communicates, and take fights only when you have the position or numbers."),
        Topic(listOf("bgmi", "pubg"),
            "BGMI / PUBG Mobile: test sensitivity in the Training Ground, start from the middle values and adjust per scope. Use the Smooth graphics + highest frame rate your device offers for the most stable play."),
        Topic(listOf("max", "free fire", "freefire", "ff"),
            "Free Fire MAX has better graphics but needs more RAM. On a phone with 4 GB or less, regular Free Fire usually runs smoother. Use the One-Tap launcher to start either one."),
        Topic(listOf("add", "launcher", "launch", "game"),
            "Use + Add Game on the home screen to add any installed game. Then tap ⚡ One-Tap Boost & Play to free memory and open it instantly."),
        Topic(listOf("hello", "hi", "hey", "help"),
            "Hi! I can help with sensitivity, headshot practice, lag/FPS, overheating, battery, network and rank tips. Tap a quick button or type a question.")
    )

    override fun build() {
        addBot("Hi, I'm your GK AI Gaming Assistant. Ask me about sensitivity, headshots, lag, heat or ranking!")

        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        val hs = HorizontalScrollView(this)
        for (q in listOf("Sensitivity", "Headshot tips", "Fix lag", "Overheating", "Rank tips")) {
            chips.addView(Ui.button(this, q, false) { ask(q) })
        }
        hs.addView(chips)
        root.addView(hs, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setBackgroundColor(Color.WHITE)
        val input = EditText(this)
        input.hint = "Ask the assistant..."
        input.setSingleLine()
        row.addView(input, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        row.addView(Ui.button(this, "Send") {
            val q = input.text.toString().trim()
            if (q.isNotEmpty()) {
                input.setText("")
                ask(q)
            }
        })
        root.addView(row, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
    }

    private fun ask(q: String) {
        addUser(q)
        val s = q.lowercase()
        val best = topics.maxByOrNull { t -> t.keys.count { s.contains(it) } }
        val score = best?.keys?.count { s.contains(it) } ?: 0
        addBot(if (best != null && score > 0) best.answer
        else "I'm not sure about that one. Try asking about sensitivity, headshots, lag, overheating, battery, network or rank tips.")
    }

    private fun addUser(s: String) = bubble(s, true)
    private fun addBot(s: String) = bubble(s, false)

    private fun bubble(s: String, user: Boolean) {
        val t = Ui.tv(this, s, 15f, false, if (user) Color.WHITE else Ui.TEXT)
        val p = Ui.dp(this, 12)
        t.setPadding(p, p, p, p)
        t.background = if (user) Ui.rounded(this, Ui.RED, radiusDp = 14)
        else Ui.rounded(this, Color.WHITE, Ui.RED, 14, 2)
        val lp = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        lp.topMargin = Ui.dp(this, 8)
        lp.gravity = if (user) Gravity.END else Gravity.START
        if (user) lp.leftMargin = Ui.dp(this, 48) else lp.rightMargin = Ui.dp(this, 48)
        content.addView(t, lp)
        scroll.post { scroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }
}
