package com.gk.gamebooster

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Small helper for the White + Red gaming look. */
object Ui {
    val RED = Color.parseColor("#E11D2E")
    val DARK_RED = Color.parseColor("#B3121F")
    val BG = Color.parseColor("#FFF4F4")
    val TEXT = Color.parseColor("#222222")
    val MUTED = Color.parseColor("#6B6B6B")
    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(c: Context, fill: Int, stroke: Int = Color.TRANSPARENT, radiusDp: Int = 14, strokeDp: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = dp(c, radiusDp).toFloat()
        if (strokeDp > 0) d.setStroke(dp(c, strokeDp), stroke)
        return d
    }

    fun tv(c: Context, s: String, sizeSp: Float = 15f, bold: Boolean = false, color: Int = TEXT): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    fun lp(c: Context, topDp: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.topMargin = dp(c, topDp)
        return p
    }

    fun card(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        l.background = rounded(c, Color.WHITE, RED, 16, 2)
        val p = dp(c, 14)
        l.setPadding(p, p, p, p)
        return l
    }

    fun button(c: Context, label: String, filled: Boolean = true, onClick: () -> Unit): Button {
        val b = Button(c)
        b.text = label
        b.isAllCaps = true
        b.setTextColor(if (filled) Color.WHITE else RED)
        b.background = if (filled) rounded(c, RED, radiusDp = 12) else rounded(c, Color.WHITE, RED, 12, 2)
        b.stateListAnimator = null
        b.setOnClickListener { onClick() }
        return b
    }

    fun iconBubble(c: Context, emoji: String, sizeDp: Int = 56): TextView {
        val t = TextView(c)
        t.text = emoji
        t.textSize = 26f
        t.gravity = android.view.Gravity.CENTER
        t.background = rounded(c, Color.parseColor("#FFE3E5"), radiusDp = sizeDp / 2)
        t.layoutParams = LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp))
        return t
    }
}
