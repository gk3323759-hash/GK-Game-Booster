package com.gk.gamebooster

import android.widget.LinearLayout
import android.widget.TextView

class TrainerActivity : BaseActivity("Headshot Training") {
    private lateinit var view: TrainerView
    private lateinit var diffText: TextView
    private lateinit var resultText: TextView
    private lateinit var bestText: TextView
    private val names = listOf("Easy", "Medium", "Hard")

    override fun build() {
        val info = Ui.card(this)
        info.addView(Ui.tv(this, "${Prefs.roundSeconds(this)}-second aim trainer", 18f, true, Ui.RED))
        info.addView(Ui.tv(this,
            "Tap the HEAD (red circle) for a headshot bonus. Body hits give fewer points. Missing resets your combo and costs points.",
            14f, false, Ui.MUTED))
        content.addView(info, Ui.lp(this))

        diffText = Ui.tv(this, "Difficulty: Medium", 15f, true)
        content.addView(diffText, Ui.lp(this, 12))
        val row = LinearLayout(this)
        for (i in names.indices) {
            val lp = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
            lp.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0)
            row.addView(Ui.button(this, names[i], false) {
                view.difficulty = i
                diffText.text = "Difficulty: ${names[i]}"
            }, lp)
        }
        content.addView(row, Ui.lp(this, 6))

        view = TrainerView(this)
        view.listener = object : TrainerView.Listener {
            override fun onFinish() = finishRound()
        }
        view.difficulty = 1
        content.addView(view, LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(this, 420)).apply { topMargin = Ui.dp(this@TrainerActivity, 12) })

        content.addView(Ui.button(this, "▶ START") { view.start(); resultText.text = "Go!" }, Ui.lp(this, 12))

        resultText = Ui.tv(this, "Your results appear here.", 15f)
        bestText = Ui.tv(this, "Best score: ${GameStore.bestScore(this)}", 15f, true, Ui.RED)
        val res = Ui.card(this)
        res.addView(resultText)
        res.addView(bestText, Ui.lp(this, 6))
        content.addView(res, Ui.lp(this, 12))
    }

    private fun finishRound() {
        val acc = if (view.shots == 0) 0 else view.hits * 100 / view.shots
        val hsRate = if (view.hits == 0) 0 else view.headshots * 100 / view.hits
        resultText.text = "Score: ${view.score}\nShots: ${view.shots}   Hits: ${view.hits}\n" +
            "Accuracy: $acc%\nHeadshots: ${view.headshots} ($hsRate% of hits)\nBest combo: ${view.bestCombo}"
        if (view.score > GameStore.bestScore(this)) {
            GameStore.saveBest(this, view.score)
            toast("New best score!")
        }
        bestText.text = "Best score: ${GameStore.bestScore(this)}"
    }
}
