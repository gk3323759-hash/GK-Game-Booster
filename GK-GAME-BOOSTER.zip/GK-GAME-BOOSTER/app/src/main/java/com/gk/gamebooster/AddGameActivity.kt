package com.gk.gamebooster

import android.content.Intent
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout

class AddGameActivity : BaseActivity("Add Game") {
    private data class AppItem(val label: String, val pkg: String, val icon: Drawable)

    private lateinit var list: LinearLayout
    private var query = ""

    private val apps: List<AppItem> by lazy {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(i, 0)
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .filter { it.pkg != packageName && it.pkg !in GameStore.builtinPackages }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    override fun build() {
        content.addView(Ui.tv(this, "Pick any installed game to add it to your One-Tap launcher.", 14f, false, Ui.MUTED))
        val search = EditText(this)
        search.hint = "Search apps"
        search.setSingleLine()
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s.toString().trim().lowercase()
                render()
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        content.addView(search, Ui.lp(this, 8))
        content.addView(list, Ui.lp(this, 8))
        render()
    }

    private fun render() {
        list.removeAllViews()
        val added = GameStore.customPackages(this)
        for (a in apps.filter { query.isEmpty() || it.label.lowercase().contains(query) }) {
            val isAdded = a.pkg in added
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val icon = ImageView(this)
            icon.setImageDrawable(a.icon)
            row.addView(icon, LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)))
            val name = Ui.tv(this, a.label, 16f)
            name.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0)
            row.addView(name, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            row.addView(Ui.button(this, if (isAdded) "Remove" else "Add", !isAdded) {
                if (isAdded) GameStore.remove(this, a.pkg) else GameStore.add(this, a.pkg)
                render()
            }, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP))
            list.addView(row, Ui.lp(this, 6))
        }
    }
}
