package com.gk.gamebooster

import android.content.Intent
import android.content.res.ColorStateList
import android.widget.LinearLayout
import android.widget.ProgressBar

class SensitivityActivity : BaseActivity("Sensitivity Settings") {
    private data class Preset(val name: String, val desc: String, val values: List<Pair<String, Int>>)

    private val freeFire = listOf(
        Preset("Rusher", "Fast turns for close-range fights.",
            listOf("General" to 100, "Red Dot" to 95, "2x Scope" to 90, "4x Scope" to 85, "AWM Scope" to 75, "Free Look" to 80)),
        Preset("Balanced", "Good all-round starting point.",
            listOf("General" to 90, "Red Dot" to 85, "2x Scope" to 80, "4x Scope" to 75, "AWM Scope" to 60, "Free Look" to 70)),
        Preset("Precision", "Slower, steadier aim for mid/long range.",
            listOf("General" to 80, "Red Dot" to 75, "2x Scope" to 70, "4x Scope" to 65, "AWM Scope" to 50, "Free Look" to 60))
    )

    private val bgmi = listOf(
        Preset("Rusher", "Quick camera for close fights.",
            listOf("No Scope" to 100, "Red Dot" to 95, "2x" to 55, "3x" to 40, "4x" to 33, "6x" to 25, "8x" to 20)),
        Preset("Balanced", "Good all-round starting point.",
            listOf("No Scope" to 95, "Red Dot" to 90, "2x" to 50, "3x" to 35, "4x" to 30, "6x" to 22, "8x" to 18)),
        Preset("Precision", "Slow and steady for long range.",
            listOf("No Scope" to 85, "Red Dot" to 80, "2x" to 45, "3x" to 30, "4x" to 25, "6x" to 18, "8x" to 15))
    )

    private var group = 0      // 0 = Free Fire / MAX, 1 = BGMI / PUBG Mobile
    private var sel = 1        // selected preset index
    private lateinit var body: LinearLayout

    override fun build() {
        content.addView(Ui.tv(this,
            "These are recommended STARTING values. Every phone and every player is different, so fine-tune in the game's training room. This app only shows suggestions – it never changes game files.",
            14f, false, Ui.MUTED))
        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        content.addView(body, Ui.lp(this, 12))
        render()
    }

    private fun render() {
        body.removeAllViews()

        // game group selector
        val g = LinearLayout(this)
        val names = listOf("Free Fire / MAX", "BGMI / PUBG Mobile")
        for (i in names.indices) {
            val lp = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
            lp.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0)
            g.addView(Ui.button(this, names[i], group == i) { group = i; render() }, lp)
        }
        body.addView(g)

        val presets = if (group == 0) freeFire else bgmi

        // preset selector
        val row = LinearLayout(this)
        for (i in presets.indices) {
            val lp = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
            lp.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0)
            row.addView(Ui.button(this, presets[i].name, sel == i) { sel = i; render() }, lp)
        }
        body.addView(row, Ui.lp(this, 8))

        // values
        val p = presets[sel]
        val card = Ui.card(this)
        card.addView(Ui.tv(this, "${p.name} preset", 18f, true, Ui.RED))
        card.addView(Ui.tv(this, p.desc, 13f, false, Ui.MUTED))
        if (group == 0) card.addView(Ui.tv(this, "Free Fire MAX uses the same sliders as Free Fire.", 12f, false, Ui.MUTED))
        for ((label, v) in p.values) {
            val line = LinearLayout(this)
            line.addView(Ui.tv(this, label, 14f), LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            line.addView(Ui.tv(this, v.toString(), 14f, true, Ui.RED))
            card.addView(line, Ui.lp(this, 10))
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
            bar.max = 100
            bar.progress = v
            bar.progressTintList = ColorStateList.valueOf(Ui.RED)
            card.addView(bar, Ui.lp(this, 2))
        }
        body.addView(card, Ui.lp(this, 12))

        // tips
        val tips = Ui.card(this)
        tips.addView(Ui.tv(this, "How to tune", 16f, true, Ui.RED))
        tips.addView(Ui.tv(this,
            "• Overshooting targets → lower values by 5–10.\n" +
            "• Turning too slowly → raise values by 5–10.\n" +
            "• Change ONE slider at a time and test 3–5 matches.\n" +
            "• Small phones → a bit higher; tablets → lower.\n" +
            "• Practise in the training room, then in Headshot Training here.", 14f), Ui.lp(this, 6))
        body.addView(tips, Ui.lp(this, 12))

        body.addView(Ui.button(this, "🎯 Test your aim in Headshot Training") {
            startActivity(Intent(this, TrainerActivity::class.java))
        }, Ui.lp(this, 12))
    }
}
