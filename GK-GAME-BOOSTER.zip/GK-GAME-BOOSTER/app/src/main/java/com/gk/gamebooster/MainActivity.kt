package com.gk.gamebooster

import android.content.Intent
import android.graphics.Color
import android.os.Environment
import android.os.StatFs
import android.view.Gravity
import android.widget.LinearLayout

/** Gaming dashboard: device stats, game launcher and tools. */
class MainActivity : BaseActivity("GK GAME BOOSTER") {
    override val showBack = false

    private data class Tool(val emoji: String, val title: String, val cls: Class<*>)

    private val tools = listOf(
        Tool("🎯", "Headshot Training", TrainerActivity::class.java),
        Tool("🎚️", "Sensitivity Settings", SensitivityActivity::class.java),
        Tool("🚀", "RAM & Performance", PerformanceActivity::class.java),
        Tool("🤖", "AI Assistant", AssistantActivity::class.java),
        Tool("💡", "Gaming Tips", TipsActivity::class.java),
        Tool("⚙️", "Settings", SettingsActivity::class.java)
    )

    override fun onResume() {
        super.onResume()
        build()
    }

    override fun build() {
        content.removeAllViews()

        // ---- Hero ----
        val hero = LinearLayout(this)
        hero.orientation = LinearLayout.VERTICAL
        hero.background = Ui.rounded(this, Ui.RED, radiusDp = 18)
        val hp = Ui.dp(this, 18)
        hero.setPadding(hp, hp, hp, hp)
        hero.addView(Ui.tv(this, "GAMING DASHBOARD", 12f, true, Color.WHITE))
        hero.addView(Ui.tv(this, "GK GAME BOOSTER", 26f, true, Color.WHITE))
        hero.addView(Ui.tv(this, "Boost • Train • Win", 14f, false, Color.WHITE))
        hero.addView(Ui.button(this, "⚡ BOOST NOW", false) {
            val n = Booster.boost(this, GameStore.allPackages(this))
            toast("Boost done: asked $n background apps to stop")
            content.postDelayed({ build() }, 800)
        }, Ui.lp(this, 12))
        content.addView(hero, Ui.lp(this))

        // ---- Live stats ----
        val mi = Booster.memInfo(this)
        val usedPct = ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toInt()
        val (bat, temp) = Booster.battery(this)
        val st = StatFs(Environment.getDataDirectory().path)
        val freeGb = String.format("%.1f GB", st.availableBytes / 1073741824.0)
        val stats = LinearLayout(this)
        stats.addView(statTile("$usedPct%", "RAM used"))
        stats.addView(statTile("$bat%", "Battery ${String.format("%.0f", temp)}°C"))
        stats.addView(statTile(freeGb, "Storage free"))
        content.addView(stats, Ui.lp(this, 12))

        // ---- Games ----
        content.addView(Ui.tv(this, "MY GAMES", 14f, true, Ui.RED), Ui.lp(this, 18))
        for (g in GameStore.all(this)) {
            val installed = GameStore.isInstalled(this, g.pkg)
            val row = Ui.card(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val left = LinearLayout(this)
            left.orientation = LinearLayout.VERTICAL
            left.addView(Ui.tv(this, g.name, 17f, true, Ui.RED))
            left.addView(Ui.tv(this, if (installed) "● Installed" else "○ Not installed", 12f, false, Ui.MUTED))
            row.addView(left, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            row.addView(Ui.button(this, "▶ PLAY") { launchGame(g) }, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP))
            if (g.custom) {
                row.addView(Ui.button(this, "✕", false) {
                    GameStore.remove(this, g.pkg)
                    build()
                }, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP))
            }
            content.addView(row, Ui.lp(this, 8))
        }
        content.addView(Ui.button(this, "+ ADD GAME") {
            startActivity(Intent(this, AddGameActivity::class.java))
        }, Ui.lp(this, 10))

        // ---- Tools ----
        content.addView(Ui.tv(this, "TOOLS", 14f, true, Ui.RED), Ui.lp(this, 18))
        var i = 0
        while (i < tools.size) {
            val row = LinearLayout(this)
            row.addView(tile(tools[i]))
            if (i + 1 < tools.size) row.addView(tile(tools[i + 1]))
            content.addView(row, Ui.lp(this, 8))
            i += 2
        }
    }

    private fun statTile(value: String, label: String): LinearLayout {
        val t = Ui.card(this)
        t.gravity = Gravity.CENTER
        val v = Ui.tv(this, value, 18f, true, Ui.RED)
        v.gravity = Gravity.CENTER
        val l = Ui.tv(this, label, 11f, false, Ui.MUTED)
        l.gravity = Gravity.CENTER
        t.addView(v)
        t.addView(l)
        val p = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
        val m = Ui.dp(this, 4)
        p.setMargins(m, 0, m, 0)
        t.layoutParams = p
        return t
    }

    private fun tile(tool: Tool): LinearLayout {
        val t = Ui.card(this)
        t.gravity = Gravity.CENTER
        t.addView(Ui.iconBubble(this, tool.emoji))
        val label = Ui.tv(this, tool.title, 14f, true, Ui.TEXT)
        label.gravity = Gravity.CENTER
        t.addView(label, Ui.lp(this, 8))
        t.setOnClickListener { startActivity(Intent(this, tool.cls)) }
        val p = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
        val m = Ui.dp(this, 4)
        p.setMargins(m, 0, m, 0)
        t.layoutParams = p
        return t
    }

    private fun launchGame(g: Game) {
        val intent = GameStore.launchIntent(this, g.pkg)
        if (intent == null) {
            toast("${g.name} is not installed on this phone")
            return
        }
        if (Prefs.autoBoost(this)) {
            val n = Booster.boost(this, GameStore.allPackages(this))
            toast("Boost done: asked $n background apps to stop")
        }
        startActivity(intent)
    }
}
